# mypackage
This library was created as an example of ho to publish your own Python package.

# How to install
...